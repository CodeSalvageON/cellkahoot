<!DOCTYPE html>
<html>
  <head>
    <title>Save Score</title>
    <link href="illusion.css" rel="stylesheet" type="text/css"/>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300&display=swap" rel="stylesheet"> 
  </head>
  <body onload="scoreCheck()">
   <form action="action.php" method="post">
    <h1 class="title-text">Username: <input type="text" pattern="[A-Za-z]" name="username"/></h1>
   </form>

    <script src="client.js"></script>
    <script src="anticheat.js"></script>
  </body>
</html>