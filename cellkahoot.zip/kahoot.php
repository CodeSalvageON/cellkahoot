<!DOCTYPE html>
<html>
  <head>
    <title>Kahoot Time!</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300&display=swap" rel="stylesheet"> 
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
  </head>
  <body>
    <h1 id="question">Question 1/31</h1>
    <h2>Questions from: <a href="https://quizlet.com/102027897/kahoot-cell-structure-and-function-flash-cards/">Here.</a></h2>
    <h1 id="score">Score: 0</h1>
    <div id="question1" class="question">
      <h1>Question 1</h1>
      <h2>Which is not true about the cell?</h2>
      <button onclick="addScore()">All cells have the same organelle</button><button onclick="wrongAnswer()">All cells have DNA</button>
    </div>
    <div id="question2" class="question">
      <h1>Question 2</h1>
      <h2>Which part of the plant cell helps it remain rigid?</h2>
      <button onclick="addScore()">central vacuole</button><button onclick="wrongAnswer()">cell wall</button>
    </div>
    <div id="question3" class="question">
          <h1>Question 3</h1>
         <h2>For cells it is important that surface area...?</h2>
      <button onclick="addScore()">Is large compared to volume</button><button onclick="wrongAnswer()">Is large compared to width</button>
    </div>
    <div id="question4" class="question">
          <h1>Question 4</h1>
      <h2>Which scientist first used the word cell?</h2>
      <button onclick="addScore()">Hooke</button><button onclick="wrongAnswer()">Darwin</button>
    </div>
    <div id="question5" class="question">
          <h1>Question 5</h1>
      <h2>Which of the following is found in both prokaryotic and eukaryotic cells?</h2>
      <button onclick="addScore()">Ribosome</button><button onclick="wrongAnswer()">Membrane</button>
    </div>
    <div id="question6" class="question">
          <h1>Question 6</h1>
      <h2>The discovery of cells is linked most directly with what?</h2>
      <button onclick="addScore()">The development of the microscope</button><button onclick="wrongAnswer()">The telescope</button>
    </div>
    <div id="question7" class="question">
          <h1>Question 7</h1>
      <h2>Which organelle allows a plant to make carbohydrates from carbon dioxide and water?</h2>
      <button onclick="addScore()">Chloroplast</button><button onclick="wrongAnswer()">vacuole</button>
    </div>
    <div id="question8" class="question">
          <h1>Question 8</h1>
      <h2>The organelle that controls what comes in and out of the cell?</h2>
      <button onclick="addScore()">Cell membrane</button><button onclick="wrongAnswer()">Cell wall</button>
    </div>
    <div id="question9" class="question">
          <h1>Question 9</h1>
      <h2>What organelle makes proteins?</h2>
      <button onclick="addScore()">Ribosomes</button><button onclick="wrongAnswer()">Nucleus</button>
    </div>
    <div id="question10" class="question">
          <h1>Question 10</h1>
      <h2>The organelle that had ribosomes on it and is the site of protein production is what?</h2>
      <button onclick="addScore()">Rough ER</button><button onclick="wrongAnswer()">Smooth ER</button>
    </div>
    <div id="question11" class="question">
          <h1>Question 11</h1>
      <h2>In which type of cells would you expect to find many mitochondrians</h2>
      <button onclick="addScore()">Muscle</button><button onclick="wrongAnswer()">Bone</button>
    </div>
    <div id="question12" class="question">
          <h1>Question 12</h1>
      <h2>Which is not true about the cell?</h2>
      <button onclick="addScore()">All cells have the same organelle</button><button onclick="wrongAnswer()">All cells have DNA</button>
    </div>
    <div id="question13" class="question">
          <h1>Question 13</h1>
      <h2>One thing that plant cells have that animal cells dont?</h2>
      <button onclick="addScore()">Cell wall</button><button onclick="wrongAnswer()">Golgi Apparatus</button>
    </div>
    <div id="question14" class="question">
          <h1>Question 14</h1>
      <h2>Which scientist said that cells could only come from other cells</h2>
      <button onclick="addScore()">Virchow</button><button onclick="wrongAnswer()">Hawking</button>
    </div>
    <div id="question15" class="question">
          <h1>Question 15</h1>
      <h2>Which scientist was the first to see living cells?</h2>
      <button onclick="addScore()">Van Leeuwenhoek</button><button onclick="wrongAnswer()">Alexander Fleming</button>
    </div>
    <div id="question16" class="question">
          <h1>Question 16</h1>
      <h2>which organelle is genetic material contained?</h2>
      <button onclick="addScore()">Nucleus</button><button onclick="wrongAnswer()">Golgi bodies</button>
    </div>
    <div id="question17" class="question">
          <h1>Question 17</h1>
      <h2>Which organelle packages products and puts an address label on it?</h2>
      <button onclick="addScore()">Golgi Apparatus</button><button onclick="wrongAnswer()">Mitochondria</button>
    </div>
    <div id="question18" class="question">
          <h1>Question 18</h1>
      <h2>Which organelle if it loses water, the plant will wilt</h2>
      <button onclick="addScore()">central vacuole</button><button onclick="wrongAnswer()">cytoplasm</button>
    </div>
    <div id="question19" class="question">      <h1>Question 19</h1>
      <h2>Which organelle turns organic molecules into ATP the energy currency of the cell</h2>
      <button onclick="addScore()">Mitochondria</button><button onclick="wrongAnswer()">Lysosome</button></div>
    <div id="question20" class="question">      <h1>Question 20</h1>
      <h2>Internal framework of the cell</h2>
      <button onclick="addScore()">Cytoskeleton</button><button onclick="wrongAnswer()">Smooth ER</button></div>
    <div id="question21" class="question">      <h1>Question 21</h1>
      <h2>The place where ribosomes are made</h2>
      <button onclick="addScore()">Nucleolus</button><button onclick="wrongAnswer()">Microtubules</button></div>
    <div id="question22" class="question">      <h1>Question 22</h1>
      <h2>A group of tissue that work together to perform a particular function is called</h2>
      <button onclick="addScore()">Organ</button><button onclick="wrongAnswer()">Organism</button></div>
    <div id="question23" class="question">      <h1>Question 23</h1>
      <h2>In the levels of organization what includes all organ systems</h2>
      <button onclick="addScore()">Organism</button><button onclick="wrongAnswer()">Organ</button></div>
    <div id="question24" class="question">      <h1>Question 24</h1>
      <h2>This structure is found in ALL prokaryotes but not in ALL eukaryotes</h2>
      <button onclick="addScore()">Nucleoid</button><button onclick="wrongAnswer()">Nuclear Membrane</button></div>
    <div id="question25" class="question">      <h1>Question 25</h1>
      <h2>What does the term semi-permeable mean?</h2>
      <button onclick="addScore()">To allow allow only certain substances through</button><button onclick="wrongAnswer()">To only allow some of one substance</button></div>
    <div id="question26" class="question">      <h1>Question 26</h1>
      <h2>During osmosis, water will moves towards the _________ side of the membrane</h2>
      <button onclick="addScore()">hypertonic</button><button onclick="wrongAnswer()">electrolyte</button></div>
    <div id="question27" class="question">      <h1>Question 27</h1>
      <h2>A cell that has less solutes than the surrounding solution is called what?</h2>
      <button onclick="addScore()">hypotonic</button><button onclick="wrongAnswer()">hypertonic</button></div>
    <div id="question28" class="question">      <h1>Question 28</h1>
      <h2>What are the channels or pumps used facilitated diffusion and active transport made of?</h2>
      <button onclick="addScore()">proteins</button><button onclick="wrongAnswer()">RNA</button></div>
    <div id="question29" class="question">      <h1>Question 29</h1>
      <h2>How does facilitated diffusion differ from diffusion?</h2>
      <button onclick="addScore()">Requires protein channel</button><button onclick="wrongAnswer()">Requires DNA strand</button></div>
    <div id="question30" class="question">      <h1>Question 30</h1>
      <h2>Vesicles are used during which type of active transport</h2>
      <button onclick="addScore()">endocytosis</button><button onclick="wrongAnswer()">water transport</button></div>
    <div id="question31" class="question">      <h1>Question 31</h1>
      <h2>Which of the following is a type of transport that requires energy?</h2>
      <button onclick="addScore()">Phagocytosis</button><button onclick="wrongAnswer()">endocytosis</button></div>
    <div id="scoreCheck">
      <form action="action.php" method="post">
    <h1 class="title-text">Username: <input type="text" name="username"/></h1>
    <h1 class="title-text" id="score_access_denied" required>score_access_denied <input type="text" name="score" id="myScore"/></h1>
    <center><input type="submit" value="Save Score"/></center>
   </form>
    </div>

    <script src="client.js"></script>
    <script src="anticheat.js"></script>
  </body>
</html>