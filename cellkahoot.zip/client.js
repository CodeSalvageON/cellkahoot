//Define basic variables regarding player data
var score = 0
var question = 1;
var position = 1;

//Hide the future questions
$('#question2').hide();
$('#question3').hide();
$('#question4').hide();
$('#question5').hide();
$('#question6').hide();
$('#question7').hide();
$('#question8').hide();
$('#question9').hide();
$('#question10').hide();
$('#question11').hide();
$('#question12').hide();
$('#question13').hide();
$('#question14').hide();
$('#question15').hide();
$('#question16').hide();
$('#question17').hide();
$('#question18').hide();
$('#question19').hide();
$('#question20').hide();
$('#question21').hide();
$('#question22').hide();
$('#question23').hide();
$('#question24').hide();
$('#question25').hide();
$('#question26').hide();
$('#question27').hide();
$('#question28').hide();
$('#question29').hide();
$('#question30').hide();
$('#question31').hide();

//Hide score saver
$('#scoreCheck').hide();

//Add score and detect player question position
function addScore(){
  score = score + 10;
  question = question + 1;
  document.getElementById('score').innerText = 'Score: '+score;
  document.getElementById('question').innerText = 'Question: '+question+'/31';
  document.getElementById('myScore').value = score;
  position = position + 1;
  if (question > 31){
    $('#scoreCheck').show();
    $('#myScore').hide();
    $('#score_access_denied').hide();
    question = question - 1;
  }
  if (position == 2){
    $('#question1').hide();
    $('#question2').show();
  }
  else if (position == 3){
    $('#question2').hide();
    $('#question3').show();
  }
  else if (position == 4){
    $('#question3').hide();
    $('#question4').show();
  }
  else if (position == 5){
    $('#question4').hide();
    $('#question5').show();
  }
  else if (position == 6){
    $('#question5').hide();
    $('#question6').show();
  }
  else if (position == 7){
    $('#question6').hide();
    $('#question7').show();
  }
  else if (position == 8){
    $('#question7').hide();
    $('#question8').show();
  }
  else if (position == 9){
    $('#question8').hide();
    $('#question9').show();
  }
  else if (position == 10){
    $('#question9').hide();
    $('#question10').show();
  }
  else if (position == 11){
    $('#question10').hide();
    $('#question11').show();
  }
  else if (position == 12){
    $('#question11').hide();
    $('#question12').show();
  }
  else if (position == 13){
    $('#question12').hide();
    $('#question13').show();
  }
  else if (position == 14){
    $('#question13').hide();
    $('#question14').show();
  }
  else if (position == 15){
    $('#question14').hide();
    $('#question15').show();
  }
  else if (position == 16){
    $('#question15').hide();
    $('#question16').show();
  }
  else if (position == 17){
    $('#question16').hide();
    $('#question17').show();
  }
  else if (position == 18){
    $('#question17').hide();
    $('#question18').show();
  }
  else if (position == 19){
    $('#question18').hide();
    $('#question19').show();
  }
  else if (position == 20){
    $('#question19').hide();
    $('#question20').show();
  }
  else if (position == 21){
    $('#question20').hide();
    $('#question21').show();
  }
  else if (position == 22){
    $('#question21').hide();
    $('#question22').show();
  }
  else if (position == 23){
    $('#question22').hide();
    $('#question23').show();
  }
  else if (position == 24){
    $('#question23').hide();
    $('#question24').show();
  }
  else if (position == 25){
    $('#question24').hide();
    $('#question25').show();
  }
  else if (position == 26){
    $('#question25').hide();
    $('#question26').show();
  }
  else if (position == 27){
    $('#question26').hide();
    $('#question27').show();
  }
  else if (position == 28){
    $('#question27').hide();
    $('#question28').show();
  }
  else if (position == 29){
    $('#question28').hide();
    $('#question29').show();
  }
  else if (position == 30){
    $('#question29').hide();
    $('#question30').show();
  }
  else if (position == 31){
    $('#question30').hide();
    $('#question31').show();
  }
  else if (position == 32){
    $('#question31').hide();
  }
  else{
    position = position - 1;
  }
}

//Detect a wrong answer and detect player question position
function wrongAnswer(){
  question = question + 1;
  document.getElementById('question').innerText = 'Question: '+question+'/31';
  position = position + 1;
  if (question > 31){
    $('#scoreCheck').show();
    $('#myScore').hide();
    $('#score_access_denied').hide();
    document.getElementById('myScore').value = score;
    question = question - 1;
  }
    if (position == 2){
    $('#question1').hide();
    $('#question2').show();
  }
  else if (position == 3){
    $('#question2').hide();
    $('#question3').show();
  }
  else if (position == 4){
    $('#question3').hide();
    $('#question4').show();
  }
  else if (position == 5){
    $('#question4').hide();
    $('#question5').show();
  }
  else if (position == 6){
    $('#question5').hide();
    $('#question6').show();
  }
  else if (position == 7){
    $('#question6').hide();
    $('#question7').show();
  }
  else if (position == 8){
    $('#question7').hide();
    $('#question8').show();
  }
  else if (position == 9){
    $('#question8').hide();
    $('#question9').show();
  }
  else if (position == 10){
    $('#question9').hide();
    $('#question10').show();
  }
  else if (position == 11){
    $('#question10').hide();
    $('#question11').show();
  }
  else if (position == 12){
    $('#question11').hide();
    $('#question12').show();
  }
  else if (position == 13){
    $('#question12').hide();
    $('#question13').show();
  }
  else if (position == 14){
    $('#question13').hide();
    $('#question14').show();
  }
  else if (position == 15){
    $('#question14').hide();
    $('#question15').show();
  }
  else if (position == 16){
    $('#question15').hide();
    $('#question16').show();
  }
  else if (position == 17){
    $('#question16').hide();
    $('#question17').show();
  }
  else if (position == 18){
    $('#question17').hide();
    $('#question18').show();
  }
  else if (position == 19){
    $('#question18').hide();
    $('#question19').show();
  }
  else if (position == 20){
    $('#question19').hide();
    $('#question20').show();
  }
  else if (position == 21){
    $('#question20').hide();
    $('#question21').show();
  }
  else if (position == 22){
    $('#question21').hide();
    $('#question22').show();
  }
  else if (position == 23){
    $('#question22').hide();
    $('#question23').show();
  }
  else if (position == 24){
    $('#question23').hide();
    $('#question24').show();
  }
  else if (position == 25){
    $('#question24').hide();
    $('#question25').show();
  }
  else if (position == 26){
    $('#question25').hide();
    $('#question26').show();
  }
  else if (position == 27){
    $('#question26').hide();
    $('#question27').show();
  }
  else if (position == 28){
    $('#question27').hide();
    $('#question28').show();
  }
  else if (position == 29){
    $('#question28').hide();
    $('#question29').show();
  }
  else if (position == 30){
    $('#question29').hide();
    $('#question30').show();
  }
  else if (position == 31){
    $('#question30').hide();
    $('#question31').show();
  }
  else if (position == 32){
    $('#question31').hide();
  }
  else{
    position = position - 1;
  }
}

//Display Score
function scoreCheck(){
  var score_check = 'Your score is: '+score;
  document.getElementById('score').innerText = score_check;
}