<html>
  <head>
    <title>Cell thingy kahoot</title>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300&display=swap" rel="stylesheet"> 
  </head> 
  <body>
    <h1 class="title-text">Cell Kahoot</h1> 
    <img src="https://pluspng.com/img-png/body-cell-png--640.png" class="zoom" onclick="location='kahoot.php';"/><div id="paragraph"><h1>Cell structure Kahoot. Click on the cell to start. Your score will be saved.</h1></div>

    <script src="anticheat.js"></script>
  </body>
</html>