<!DOCTYPE html>
<html>
  <head>
    <title>ScoreBoard</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
  <center><h1>ScoreBoard</h1></center>
  <center><a href="https://cellkahoot.codesalvageon.repl.co"><h1>Play Again</h1></a></center>
  <center><h1 class="marker">Lowest scores at the top</h1></center>
    <?php
    $wordlist = glob('scores/*');

  foreach($wordlist as $wordname){
    echo "<h1>".$wordname."</h1>";
  }
    ?>
    <footer><center><h1 class="marker">Highest Scores at the bottom</h1></center></footer>
  </body>
</html>