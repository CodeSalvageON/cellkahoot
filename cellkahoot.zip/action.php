<html>
  <head>
    <title>HTML5 Null</title>
  </head>
  <body>
    <?php
    $score_save = fopen('./scores/'.$_POST['score'].'-'.$_POST['username'], 'a+');
    ?>
  </body>
  <script>location = 'scoreboard.php';</script>
</html>